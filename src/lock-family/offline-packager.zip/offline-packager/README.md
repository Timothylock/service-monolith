# Offline Packager

The purpose of the offline packager service is to facilitate with downloading all the contents for a part ID. This includes comments, story text, and media. This endpoint will be used by the offline story reading functionality for premium users in our mobile apps.

This is broken down into two services - the worker and server.

| System Characteristic | Description |
|--------------------|------------|
| SLO (Availability) | 99.99% |
| SLO (Latency Median) | 20 seconds |
| SLO (Latency 95th) | 20 seconds |
| Service Owner | Money Squad |
| K8 Cluster | prod-v1 |
| Monitoring | [DataDog](https://app.datadoghq.com/dash/571938/offline-packager) |
| Logging | [Sumo](TODO) - `search for X `|
| Alerts | [Alerts](https://app.datadoghq.com/monitors#manage?query=%5BTODO%5D) |

## Detailed Service Design Doc

https://docs.google.com/document/d/1F7J6VfNmjTxCzVRKN_I_8pc3lxN-0QXnCQsBHjBczR8/edit#


## Technical Overview

### System Overview

![System overview diagram][docs/overview.png]

### Resources
The service will be using multiple resources. The resources are as follows:
- [A client-facing HTTP service](https://github.com/Wattpad/highlander/tree/master/wattpad/src/services/offline-packager/cmd/server)
- [A background service](https://github.com/Wattpad/highlander/tree/master/wattpad/src/services/offline-packager/cmd/worker)
- [Amazon S3 bucket](https://s3.console.aws.amazon.com/s3/buckets/wattpad.offline-packager/?region=us-east-1&tab=overview)
- [Amazon simple queue service](https://sqs.us-east-1.amazonaws.com/723255503624/offline_packager)


### Service Overview - Server (client-facing HTTP service)
This code below is compatible with https://code2flow.com/app to generate a diagram
```
Offline-packager-server receives request;
if (zip file in S3){
  generate S3 link;
  return return link;
} else {
  add partID to SQS;
  return return response saying to try again later;
}
```

### Service Overview - Worker (background service)
This code below is compatible with https://code2flow.com/app to generate a diagram
```
offline-packager-worker starts;
while(partID is in SQS){
  get partID;
  if(!story ZIP exists in S3){
    get content (e.g. storyText, comments, media, etc);
  zip up the file;
  store into S3;
  }
}
```

## Operational Details

### Datadog Dashboard 

https://app.datadoghq.com/dash/571938/offline-packager

### Deploying

Merge with master and Travis will build the image. Kube-deploy will deploy the image to our cluster

### Environment Variables

TODO

### Secrets

TODO
