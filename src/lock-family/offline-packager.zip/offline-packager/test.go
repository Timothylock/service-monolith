package main

import (
	"fmt"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/sqs"
)

func main() {
	awsSession := session.Must(session.NewSession(aws.NewConfig().WithRegion("us-east-1")))
	thr := s3.New(awsSession)
	s := sqs.New(awsSession)

	params := &s3.HeadObjectInput{
		Bucket: aws.String("wattpad.offline-packager"),
		Key:    aws.String("290522447.zip"),
	}

	// Make sure that the file exists
	h, err := thr.HeadObject(params)
	if aerr, ok := err.(awserr.Error); ok {
		switch aerr.Code() {
		case "NotFound":
			fmt.Println("NOT FOUND")
		default:
			fmt.Println(aerr)
		}
	} else if err != nil {
		fmt.Println(err)
	}

	fmt.Println(h)

	sqsMsg := &sqs.SendMessageInput{
		MessageAttributes: map[string]*sqs.MessageAttributeValue{
			"StoryID": {
				DataType:    aws.String("String"),
				StringValue: aws.String("123"),
			},
			"PartID": {
				DataType:    aws.String("String"),
				StringValue: aws.String("1234"),
			},
		},
		QueueUrl:    aws.String("https://sqs.us-east-1.amazonaws.com/723255503624/offline_packager"),
		MessageBody: aws.String("nanananana batmaannnn"),
	}

	r, err := s.SendMessage(sqsMsg)
	fmt.Println(err)
	fmt.Println(r)
}

/*
root@offline-packager-server-3879212754-8g3b1:/# go run test.go
<nil>
{
  MD5OfMessageAttributes: "318483d8989d04758eb231fcb1f444f8",
  MD5OfMessageBody: "4ac4a1a9478c8d33086677d3779f70c2",
  MessageId: "54ae2c77-4258-4b40-9a48-31e612db6d50"
}
*/
