package main

import (
	"context"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"services/offline-packager/cmd/server/packaging"
	"services/offline-packager/internal/config"
	"services/offline-packager/internal/instrumentation"
	"services/offline-packager/internal/permissions"
	"services/offline-packager/internal/queue"
	"services/offline-packager/internal/storage"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/sqs"
	"github.com/go-kit/kit/log"
	"github.com/go-kit/kit/metrics/dogstatsd"
	"github.com/julienschmidt/httprouter"
)

func main() {
	logger := initializeLogger()
	logger.Log("msg", "service.start")
	defer logger.Log("msg", "service.stop")

	signals := make(chan os.Signal, 2)
	signal.Notify(signals, syscall.SIGINT, syscall.SIGTERM)

	// If the HTTP server exits and returns an error, tell the main thread to
	// shutdown by sending the error to the exit channel.
	exit := make(chan error)

	c, err := config.FromEnvironment()
	if err != nil {
		logger.Log("msg", "could not load environment", "error", err)
		os.Exit(1)
	}

	statsd := dogstatsd.New("wattpad.", log.NewContext(logger).With("subsystem", "datadog"))

	awsSession := session.Must(session.NewSession(aws.NewConfig().WithRegion(c.AWSRegion)))
	s := storage.New(s3.New(awsSession), c.S3Bucket)
	q := queue.New(sqs.New(awsSession), c.SQSURL)
	v := permissions.New(c.ValidatorURL)

	srv := &http.Server{
		Handler: newAPI(logger, *instrumentation.New(c.DatadogAddress, c.DatadogFlushInterval, *statsd), v, s, q),
		Addr:    "127.0.0.1:8080",
	}
	go func() { exit <- srv.ListenAndServe() }()

	// Block until either the HTTP server exits with an error or the process
	// receives a termination signal, whichever happens to occur first.
	select {
	case sig := <-signals:
		logger.Log("signal", sig)
	case err := <-exit:
		logger.Log("msg", "service.exit", "error", err)
	}

	// Shut down the service gracefully since it may have app store connections open
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	srv.Shutdown(ctx)
}

func newAPI(logger log.Logger, t instrumentation.Tracker, v permissions.Validator, p storage.Persister, m queue.Messaging) *httprouter.Router {
	c := packaging.NewController(v, p, m, logger, t)

	router := httprouter.New()
	router.GET("/health", healthCheck)
	router.GET("/stories/:story_id/parts/offline_bundle", c.GetOfflinePackages)

	return router
}

func initializeLogger() log.Logger {
	logger := log.NewJSONLogger(log.NewSyncWriter(os.Stdout))
	logger = log.NewContext(logger).With("service", "offline-packager-server", "timestamp", log.DefaultTimestampUTC)
	return logger
}

// healthCheck is the endpoint for checking health of server
func healthCheck(rw http.ResponseWriter, _ *http.Request, _ httprouter.Params) {
	rw.WriteHeader(http.StatusOK)
}
