package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"mime"
	"net/http"
	"net/http/httptest"
	"reflect"
	"testing"
	"time"

	"services/offline-packager/cmd/server/packaging"
	"services/offline-packager/internal/instrumentation"
	"services/offline-packager/internal/permissions"
	"services/offline-packager/internal/queue"
	"services/offline-packager/internal/storage"

	"github.com/go-kit/kit/log"
	"github.com/go-kit/kit/metrics/dogstatsd"
	"github.com/golang/mock/gomock"
	"github.com/stretchr/testify/assert"
)

func MakeGetRequest(t *testing.T, url string) (string, error) {
	res, err := http.DefaultClient.Get(url)
	if err != nil {
		return "", err
	}
	defer res.Body.Close()

	contentType, _, err := mime.ParseMediaType(res.Header.Get("Content-Type"))
	assert.Nil(t, err)
	assert.Equal(t, "application/json", contentType)

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return "", err
	}
	return string(body), nil
}

func TestGetOffline(t *testing.T) {
	type testCase struct {
		setMocks       func(*permissions.MockValidator, *storage.MockPersister, *queue.MockMessaging)
		normalResponse *packaging.Response
		errorResponse  *packaging.ErrorResponse
	}

	testCases := []testCase{
		// Validator failed
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(false, nil)
			},
			errorResponse: &packaging.ErrorResponse{
				InternalCode: 1001,
				Message:      "you do not have access to a partID",
			},
		},
		// Validator passes, file was found
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("1234").Return("someURL", nil)
			},
			normalResponse: &packaging.Response{
				Ready: map[string]string{"1234": "someURL"},
			},
		},
		// Validator passes, file was not found
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("1234").Return("", storage.ErrNotFound)
				m.EXPECT().Post(queue.Message{PartID: "1234", StoryID: "321"}).Return(nil)
			},
			normalResponse: &packaging.Response{
				Processing: []string{"1234"},
			},
		},
	}

	statsd := dogstatsd.New("wattpad.", log.NewContext(log.NewNopLogger()).With("subsystem", "datadog"))
	tracker := instrumentation.New("localhost", time.Second, *statsd)

	for i, tc := range testCases {
		t.Run(fmt.Sprintf("Test case %d", i), func(t *testing.T) {
			mc := gomock.NewController(t)
			// Because if validator returns false, Persister and Messaging wont run, we need to reset the gomocks for every test
			mockValidator := permissions.NewMockValidator(mc)
			mockPersister := storage.NewMockPersister(mc)
			mockMessaging := queue.NewMockMessaging(mc)
			tc.setMocks(mockValidator, mockPersister, mockMessaging)

			serv := httptest.NewServer(newAPI(log.NewNopLogger(), *tracker, mockValidator, mockPersister, mockMessaging))
			response, err := MakeGetRequest(t, serv.URL+"/stories/321/parts/offline_bundle?partids=1234&wp_token=bleh")
			if err != nil {
				t.Fatalf("test %d - %s", i, err.Error())
			}

			// normalResponse is not empty - compare the normal response
			if tc.normalResponse != nil {
				var resp packaging.Response
				err = json.Unmarshal([]byte(response), &resp)
				if err != nil {
					t.Fatalf("test %d - %s", i, err.Error())
				}

				if !reflect.DeepEqual(*tc.normalResponse, resp) {
					expect, err := json.Marshal(tc.normalResponse)
					if err != nil {
						t.Fatalf("test %d - %s", i, err.Error())
					}

					t.Fatalf("test %d - expected %s, got %s", i, string(expect), response)
				}
			} else if tc.errorResponse != nil { // errorResponse is not empty - compare the error response
				var resp packaging.ErrorResponse
				err = json.Unmarshal([]byte(response), &resp)
				if err != nil {
					t.Fatalf("test %d - %s", i, err.Error())
				}

				if !reflect.DeepEqual(*tc.errorResponse, resp) {
					expect, err := json.Marshal(tc.errorResponse)
					if err != nil {
						t.Fatalf("test %d - %s", i, err.Error())
					}

					t.Fatalf("test %d - expected %s, got %s", i, string(expect), response)
				}
			}
			mc.Finish()
		})
	}
}

func TestGetOfflineMultipleParts(t *testing.T) {
	type testCase struct {
		setMocks       func(*permissions.MockValidator, *storage.MockPersister, *queue.MockMessaging)
		normalResponse *packaging.Response
		errorResponse  *packaging.ErrorResponse
	}

	testCases := []testCase{
		// Any unauthorised access should result in an error
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(false, nil)
			},
			errorResponse: &packaging.ErrorResponse{
				InternalCode: 1001,
				Message:      "you do not have access to a partID",
			},
		},
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("1234").Return("someURL", nil)

				v.EXPECT().Validate("5678", gomock.Any()).Return(false, nil)
			},
			errorResponse: &packaging.ErrorResponse{
				InternalCode: 1001,
				Message:      "you do not have access to a partID",
			},
		},
		// One avail, one not
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("1234").Return("someURL", nil)

				v.EXPECT().Validate("5678", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("5678").Return("", storage.ErrNotFound)
				m.EXPECT().Post(queue.Message{PartID: "5678", StoryID: "321"}).Return(nil)
			},
			normalResponse: &packaging.Response{
				Ready:      map[string]string{"1234": "someURL"},
				Processing: []string{"5678"},
			},
		},
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("1234").Return("", storage.ErrNotFound)
				m.EXPECT().Post(queue.Message{PartID: "1234", StoryID: "321"}).Return(nil)

				v.EXPECT().Validate("5678", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("5678").Return("someURL", nil)
			},
			normalResponse: &packaging.Response{
				Ready:      map[string]string{"5678": "someURL"},
				Processing: []string{"1234"},
			},
		},
		// Both available
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("1234").Return("someURL", nil)

				v.EXPECT().Validate("5678", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("5678").Return("someURL", nil)
			},
			normalResponse: &packaging.Response{
				Ready: map[string]string{"1234": "someURL", "5678": "someURL"},
			},
		},
		// Both not available yet
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("1234").Return("", storage.ErrNotFound)
				m.EXPECT().Post(queue.Message{PartID: "1234", StoryID: "321"}).Return(nil)

				v.EXPECT().Validate("5678", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("5678").Return("", storage.ErrNotFound)
				m.EXPECT().Post(queue.Message{PartID: "5678", StoryID: "321"}).Return(nil)
			},
			normalResponse: &packaging.Response{
				Processing: []string{"1234", "5678"},
			},
		},
	}

	statsd := dogstatsd.New("wattpad.", log.NewContext(log.NewNopLogger()).With("subsystem", "datadog"))
	tracker := instrumentation.New("localhost", time.Second, *statsd)

	for i, tc := range testCases {
		t.Run(fmt.Sprintf("Test case %d", i), func(t *testing.T) {
			mc := gomock.NewController(t)
			// Because if validator returns false, Persister and Messaging wont run, we need to reset the gomocks for every test
			mockValidator := permissions.NewMockValidator(mc)
			mockPersister := storage.NewMockPersister(mc)
			mockMessaging := queue.NewMockMessaging(mc)
			tc.setMocks(mockValidator, mockPersister, mockMessaging)

			serv := httptest.NewServer(newAPI(log.NewNopLogger(), *tracker, mockValidator, mockPersister, mockMessaging))

			response, err := MakeGetRequest(t, serv.URL+"/stories/321/parts/offline_bundle?partids=1234,5678&wp_token=bleh")
			if err != nil {
				t.Fatalf("test %d - %s", i, err.Error())
			}

			// normalResponse is not empty - compare the normal response
			if tc.normalResponse != nil {
				var resp packaging.Response
				err = json.Unmarshal([]byte(response), &resp)
				if err != nil {
					t.Fatalf("test %d - %s", i, err.Error())
				}

				if !reflect.DeepEqual(*tc.normalResponse, resp) {
					expect, err := json.Marshal(tc.normalResponse)
					if err != nil {
						t.Fatalf("test %d - %s", i, err.Error())
					}

					t.Fatalf("test %d - expected %s, got %s", i, string(expect), response)
				}
			} else if tc.errorResponse != nil {
				var resp packaging.ErrorResponse
				err = json.Unmarshal([]byte(response), &resp)
				if err != nil {
					t.Fatalf("test %d - %s", i, err.Error())
				}

				if !reflect.DeepEqual(*tc.errorResponse, resp) {
					expect, err := json.Marshal(tc.errorResponse)
					if err != nil {
						t.Fatalf("test %d - %s", i, err.Error())
					}

					t.Fatalf("test %d - expected %s, got %s", i, string(expect), response)
				}
			}
			mc.Finish()
		})
	}
}

func TestGetOfflineErrors(t *testing.T) {
	expectedError := &packaging.ErrorResponse{
		InternalCode: 1000,
		Message:      "An internal error occurred while processing the request",
	}

	type testCase struct {
		setMocks func(*permissions.MockValidator, *storage.MockPersister, *queue.MockMessaging)
	}

	testCases := []testCase{
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(true, errors.New("oops"))
			},
		},
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("1234").Return("", errors.New("arrrgghhh"))
			},
		},
		{
			setMocks: func(v *permissions.MockValidator, p *storage.MockPersister, m *queue.MockMessaging) {
				v.EXPECT().Validate("1234", gomock.Any()).Return(true, nil)
				p.EXPECT().Get("1234").Return("", storage.ErrNotFound)
				m.EXPECT().Post(queue.Message{PartID: "1234", StoryID: "321"}).Return(errors.New("GOSH DARNIT"))
			},
		},
	}

	statsd := dogstatsd.New("wattpad.", log.NewContext(log.NewNopLogger()).With("subsystem", "datadog"))
	tracker := instrumentation.New("localhost", time.Second, *statsd)

	for i, tc := range testCases {
		t.Run(fmt.Sprintf("Test case %d", i), func(t *testing.T) {
			mc := gomock.NewController(t)
			// Because if validator returns false, Persister and Messaging wont run, we need to reset the gomocks for every test
			mockValidator := permissions.NewMockValidator(mc)
			mockPersister := storage.NewMockPersister(mc)
			mockMessaging := queue.NewMockMessaging(mc)
			tc.setMocks(mockValidator, mockPersister, mockMessaging)

			serv := httptest.NewServer(newAPI(log.NewNopLogger(), *tracker, mockValidator, mockPersister, mockMessaging))

			response, err := MakeGetRequest(t, serv.URL+"/stories/321/parts/offline_bundle?partids=1234&wp_token=bleh")
			if err != nil {
				t.Fatalf("test %d - %s", i, err.Error())
			}

			var resp packaging.ErrorResponse
			err = json.Unmarshal([]byte(response), &resp)
			if err != nil {
				t.Fatalf("test %d - %s", i, err.Error())
			}

			if !reflect.DeepEqual(*expectedError, resp) {
				expect, err := json.Marshal(expectedError)
				if err != nil {
					t.Fatalf("test %d - %s", i, err.Error())
				}

				t.Fatalf("test %d - expected %s, got %s", i, string(expect), response)
			}
			mc.Finish()
		})
	}
}

func TestBadParams(t *testing.T) {
	type testCase struct {
		url           string
		expectedError *packaging.ErrorResponse
	}

	testCases := []testCase{
		// Missing token
		{
			url: "/stories/321/parts/offline_bundle?partids=1234",
			expectedError: &packaging.ErrorResponse{
				InternalCode: 1001,
				Message:      "missing wptoken",
			},
		},
		// Missing partids param
		{
			url: "/stories/321/parts/offline_bundle?wp_token=beh",
			expectedError: &packaging.ErrorResponse{
				InternalCode: 1001,
				Message:      "missing partids parameter",
			},
		},
		// No part supplied with partids
		{
			url: "/stories/321/parts/offline_bundle?partids=&wp_token=beh",
			expectedError: &packaging.ErrorResponse{
				InternalCode: 1001,
				Message:      "missing partID",
			},
		},
	}

	statsd := dogstatsd.New("wattpad.", log.NewContext(log.NewNopLogger()).With("subsystem", "datadog"))
	tracker := instrumentation.New("localhost", time.Second, *statsd)

	for i, tc := range testCases {
		t.Run(fmt.Sprintf("Test case %d", i), func(t *testing.T) {
			serv := httptest.NewServer(newAPI(log.NewNopLogger(), *tracker, nil, nil, nil))

			response, err := MakeGetRequest(t, serv.URL+tc.url)
			if err != nil {
				t.Fatalf("test %d - %s", i, err.Error())
			}

			var resp packaging.ErrorResponse
			err = json.Unmarshal([]byte(response), &resp)
			if err != nil {
				t.Fatalf("test %d - %s", i, err.Error())
			}

			if !reflect.DeepEqual(*tc.expectedError, resp) {
				expect, err := json.Marshal(tc.expectedError)
				if err != nil {
					t.Fatalf("test %d - %s", i, err.Error())
				}

				t.Fatalf("test %d - expected %s, got %s", i, string(expect), response)
			}
		})
	}
}
