package packaging

import (
	"encoding/json"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"services/offline-packager/internal/instrumentation"
	"services/offline-packager/internal/permissions"
	"services/offline-packager/internal/queue"
	"services/offline-packager/internal/storage"

	"github.com/go-kit/kit/log"
	"github.com/julienschmidt/httprouter"
	"github.com/pkg/errors"
)

var (
	errNotReady       = errors.New("the part is being generated")
	errMissingWPToken = errors.New("missing wptoken")
	errMissingPartID  = errors.New("missing partID")
	errUnauthorized   = errors.New("you do not have access to a partID")
)

type Controller struct {
	validator permissions.Validator
	persister storage.Persister
	messaging queue.Messaging
	logger    log.Logger
	tracker   instrumentation.Tracker
}

type Response struct {
	Ready      map[string]string `json:"ready,omitempty"`
	Processing []string          `json:"processing,omitempty"`
}

func NewController(v permissions.Validator, p storage.Persister, m queue.Messaging, l log.Logger, t instrumentation.Tracker) *Controller {
	return &Controller{
		validator: v,
		persister: p,
		messaging: m,
		logger:    l,
		tracker:   t,
	}
}

// GetOfflinePackages returns the URL to the partID offline zip file if it exists. If not, it will put a message onto
// the queue to have it generated.
func (c Controller) GetOfflinePackages(rw http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	start := time.Now()

	defer func() {
		c.tracker.TrackResponseTime(time.Since(start).Seconds() * 1000)
	}()

	storyID := ps.ByName("story_id")
	if _, err := strconv.Atoi(storyID); err != nil {
		c.tracker.TrackServerError()
		c.sendError(rw, c.badRequest(errors.New("malformed story_id"), r))
	}

	wptoken, keysArr, err := c.getInputs(r.URL.Query())
	if err != nil {
		c.tracker.TrackServerError()
		c.sendError(rw, c.badRequest(err, r))
		return
	}

	ready := make(map[string]string)
	var processing []string

	for _, key := range keysArr {
		if key == "" {
			c.tracker.TrackServerError()
			c.sendError(rw, c.badRequest(errMissingPartID, r))
			return
		}

		validatorStart := time.Now()

		allowed, err := c.validator.Validate(key, wptoken)
		if err != nil {
			c.tracker.TrackServerError()
			c.sendError(rw, c.internalError(err))
			return
		}

		c.tracker.TrackValidationTime(time.Since(validatorStart).Seconds() * 1000)

		if !allowed {
			c.sendError(rw, c.badRequest(errUnauthorized, r))
			return
		}

		url, err := c.getOfflinePackage(storyID, key)
		if err == nil {
			ready[key] = url
		} else if err == errNotReady {
			processing = append(processing, key)
		} else {
			c.tracker.TrackServerError()
			c.sendError(rw, c.internalError(err))
			return
		}
	}

	response := Response{
		Ready:      ready,
		Processing: processing,
	}

	rw.Header().Set("Content-Type", "application/json")
	rw.WriteHeader(http.StatusOK)
	if err := json.NewEncoder(rw).Encode(&response); err != nil {
		c.tracker.TrackServerError()
		c.sendError(rw, c.internalError(err))
	}
}

func (c Controller) getInputs(r url.Values) (string, []string, error) {
	wptoken := r.Get("wp_token")
	if wptoken == "" {
		return "", []string{}, errMissingWPToken
	}

	keys, ok := r["partids"]
	if !ok {
		return "", []string{}, errors.New("missing partids parameter")
	}
	keysArr := strings.Split(keys[0], ",")

	if len(keysArr) == 0 {
		return "", []string{}, errors.New("missing partids")
	}

	return wptoken, keysArr, nil
}

func (c Controller) getOfflinePackage(storyID, partID string) (string, error) {
	url, err := c.persister.Get(partID)
	if err == nil {
		return url, nil
	}

	if err != storage.ErrNotFound {
		return "", err
	}

	if err := c.messaging.Post(queue.Message{PartID: partID, StoryID: storyID}); err != nil {
		return "", err
	}

	return "", errNotReady
}
