package packaging

import (
	"encoding/json"
	"net/http"
)

type ErrorResponse struct {
	HttpCode     int    `json:"-"`
	InternalCode int    `json:"code"`
	Message      string `json:"message"`
}

func (c Controller) sendError(rw http.ResponseWriter, e ErrorResponse) {
	rw.Header().Set("Content-Type", "application/json")
	rw.WriteHeader(e.HttpCode)
	if err := json.NewEncoder(rw).Encode(&e); err != nil {
		c.sendError(rw, c.internalError(err))
	}
}

func (c Controller) internalError(e error) ErrorResponse {
	c.logger.Log("msg", "internal error", "error", e)
	return ErrorResponse{
		HttpCode:     http.StatusInternalServerError,
		InternalCode: 1000,
		Message:      "An internal error occurred while processing the request",
	}

}

func (c Controller) badRequest(e error, r *http.Request) ErrorResponse {
	c.logger.Log("msg", "bad request", "error", e, "URL", r.URL, "useragent", r.UserAgent(), "headers", r.Header)
	return ErrorResponse{
		HttpCode:     http.StatusBadRequest,
		InternalCode: 1001,
		Message:      e.Error(),
	}
}
