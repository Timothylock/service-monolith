package main

import (
	"encoding/json"
	"fmt"
	"testing"
	"time"

	"services/offline-packager/cmd/worker/packaging"
	"services/offline-packager/internal/comments"
	"services/offline-packager/internal/instrumentation"
	"services/offline-packager/internal/media"
	"services/offline-packager/internal/queue"
	"services/offline-packager/internal/storage"

	"github.com/go-kit/kit/log"
	"github.com/go-kit/kit/metrics/dogstatsd"
	"github.com/golang/mock/gomock"
	"github.com/pkg/errors"
	"github.com/stretchr/testify/assert"
)

func TestProcessPart(t *testing.T) {
	type testCase struct {
		setMocks      func(*storage.MockPersister, *media.MockParts, *comments.MockParts)
		errorReturned bool
	}

	story := "1234"
	part := "5678"
	path := fmt.Sprintf("/tmp/offline-packager/%s_%s/", story, part)

	msg := queue.Message{
		PartID:  part,
		StoryID: story,
	}
	msgByte, err := json.Marshal(msg)
	assert.Nil(t, err)

	someError := errors.New("some error")

	testCases := []testCase{
		// No errors
		{
			setMocks: func(p *storage.MockPersister, m *media.MockParts, c *comments.MockParts) {
				p.EXPECT().PartExists(part).Return(false, nil)
				p.EXPECT().IsLocked(part).Return(false, nil)
				p.EXPECT().Lock(part).Return(nil)

				m.EXPECT().Fetch(story, part, path).Return(nil)
				c.EXPECT().Fetch(part, path).Return(nil)
				p.EXPECT().Put(part, fmt.Sprintf("/tmp/offline-packager/%s.zip", part)).Return(nil)

				p.EXPECT().Unlock(part).Return(nil)
			},
			errorReturned: false,
		},
		// Part Already Exists
		{
			setMocks: func(p *storage.MockPersister, m *media.MockParts, c *comments.MockParts) {
				p.EXPECT().PartExists(part).Return(true, nil)
			},
			errorReturned: false,
		},
		// Part Already Exists Failure
		{
			setMocks: func(p *storage.MockPersister, m *media.MockParts, c *comments.MockParts) {
				p.EXPECT().PartExists(part).Return(false, someError)
			},
			errorReturned: true,
		},
		// Files is locked should not return any errors, but later packages should not be called
		{
			setMocks: func(p *storage.MockPersister, m *media.MockParts, c *comments.MockParts) {
				p.EXPECT().PartExists(part).Return(false, nil)
				p.EXPECT().IsLocked(part).Return(true, nil)
			},
			errorReturned: false,
		},
		// Failure of lock check
		{
			setMocks: func(p *storage.MockPersister, m *media.MockParts, c *comments.MockParts) {
				p.EXPECT().PartExists(part).Return(false, nil)
				p.EXPECT().IsLocked(part).Return(false, someError)
			},
			errorReturned: true,
		},
		// Set Lock Failure
		{
			setMocks: func(p *storage.MockPersister, m *media.MockParts, c *comments.MockParts) {
				p.EXPECT().IsLocked(part).Return(false, nil)
				p.EXPECT().PartExists(part).Return(false, nil)
				p.EXPECT().Lock(part).Return(someError)
			},
			errorReturned: true,
		},
		// Fetch Media Error
		{
			setMocks: func(p *storage.MockPersister, m *media.MockParts, c *comments.MockParts) {
				p.EXPECT().IsLocked(part).Return(false, nil)
				p.EXPECT().PartExists(part).Return(false, nil)
				p.EXPECT().Lock(part).Return(nil)

				m.EXPECT().Fetch(story, part, path).Return(someError)
			},
			errorReturned: true,
		},
		// Fetch Comment Error
		{
			setMocks: func(p *storage.MockPersister, m *media.MockParts, c *comments.MockParts) {
				p.EXPECT().IsLocked(part).Return(false, nil)
				p.EXPECT().PartExists(part).Return(false, nil)
				p.EXPECT().Lock(part).Return(nil)

				m.EXPECT().Fetch(story, part, path).Return(nil)
				c.EXPECT().Fetch(part, path).Return(someError)
			},
			errorReturned: true,
		},
		// Put Error
		{
			setMocks: func(p *storage.MockPersister, m *media.MockParts, c *comments.MockParts) {
				p.EXPECT().IsLocked(part).Return(false, nil)
				p.EXPECT().PartExists(part).Return(false, nil)
				p.EXPECT().Lock(part).Return(nil)

				m.EXPECT().Fetch(story, part, path).Return(nil)
				c.EXPECT().Fetch(part, path).Return(nil)
				p.EXPECT().Put(part, fmt.Sprintf("/tmp/offline-packager/%s.zip", part)).Return(someError)
			},
			errorReturned: true,
		},
		// Deleting the lock error. Should not actually return an error since it doesn't affect the user and we don't
		// need to regenerate since the lock will auto delete itself after 1 day
		{
			setMocks: func(p *storage.MockPersister, m *media.MockParts, c *comments.MockParts) {
				p.EXPECT().IsLocked(part).Return(false, nil)
				p.EXPECT().PartExists(part).Return(false, nil)
				p.EXPECT().Lock(part).Return(nil)

				m.EXPECT().Fetch(story, part, path).Return(nil)
				c.EXPECT().Fetch(part, path).Return(nil)
				p.EXPECT().Put(part, fmt.Sprintf("/tmp/offline-packager/%s.zip", part)).Return(nil)

				p.EXPECT().Unlock(part).Return(someError)
			},
			errorReturned: false,
		},
	}

	statsd := dogstatsd.New("wattpad.", log.NewContext(log.NewNopLogger()).With("subsystem", "datadog"))
	tracker := instrumentation.New("localhost", time.Second, *statsd)

	for i, tc := range testCases {
		t.Run(fmt.Sprintf("Test case %d", i), func(t *testing.T) {
			mc := gomock.NewController(t)
			mockPersister := storage.NewMockPersister(mc)
			mockMedia := media.NewMockParts(mc)
			mockComments := comments.NewMockParts(mc)
			tc.setMocks(mockPersister, mockMedia, mockComments)

			ctl := packaging.NewController(log.NewNopLogger(), *tracker, mockMedia, mockComments, mockPersister)
			err = ctl.ProcessMessage(nil, string(msgByte))

			assert.Equal(t, tc.errorReturned, err != nil)

			mc.Finish()
		})
	}
}
