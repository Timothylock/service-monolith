package main

import (
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"services/offline-packager/cmd/worker/packaging"
	"services/offline-packager/internal/config"
	"services/offline-packager/internal/instrumentation"
	"services/offline-packager/internal/storage"

	"github.com/Wattpad/sqsconsumer"
	"github.com/Wattpad/sqsconsumer/middleware"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	kitlog "github.com/go-kit/kit/log"
	"github.com/go-kit/kit/metrics"
	"github.com/go-kit/kit/metrics/discard"
	"github.com/go-kit/kit/metrics/dogstatsd"
	"github.com/pkg/errors"
	"golang.org/x/net/context"
)

func main() {
	logger := kitlog.NewContext(kitlog.NewJSONLogger(kitlog.NewSyncWriter(os.Stdout))).With("service", "offline-packager-worker")

	// set up a context for graceful shutdown on interrupt/kill
	ctx, cancel := context.WithCancel(context.Background())
	term := make(chan os.Signal, 2)
	signal.Notify(term, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-term
		logger.Log("msg", "starting shutdown")
		cancel()
	}()

	err := run(ctx, logger)
	if err != nil {
		logger.Log("msg", "fatal.error", "error", err.Error())
		os.Exit(1)
	}
}

func run(ctx context.Context, logger kitlog.Logger) error {
	queueName := os.Getenv("QUEUE_NAME")
	sqsEndpoint := os.Getenv("SQS_ENDPOINT")

	if queueName == "" {
		return errors.New("Missing required environment variable")
	}

	c, err := config.FromEnvironment()
	if err != nil {
		logger.Log("msg", "could not load environment", "error", err)
		os.Exit(1)
	}

	s, err := initializeSQSConsumer(logger, queueName, sqsEndpoint, c.AWSRegion)
	if err != nil {
		return err
	}

	dd := initializeDD(logger, queueName, c.DogstatsdHost)
	hist := dd.NewTiming("worker.time", 1.0).With("worker", "offline-packager-worker", "queue", queueName)
	stack := middleware.DefaultStack(ctx, s)
	stack = append(stack, datadogTimeTrackerMiddleware(hist))

	ss := s3.New(session.Must(session.NewSession(aws.NewConfig().WithRegion(c.AWSRegion))))
	cs := packaging.NewController(logger, *instrumentation.New(c.DatadogAddress, c.DatadogFlushInterval, *dd), mockMediaFetcher{}, mockCommentFetcher{}, storage.New(ss, c.S3Bucket))

	h := middleware.ApplyDecoratorsToHandler(cs.ProcessMessage, stack...)

	qc := sqsconsumer.NewConsumer(s, h)

	logger.Log("msg", "sqs.consumer.started")
	qc.Run(ctx)
	logger.Log("msg", "sqs.consumer.stopped")
	return nil
}

// initializeDD returns an initialized dogstatsd object
func initializeDD(logger kitlog.Logger, queueName, ddHost string) *dogstatsd.Dogstatsd {
	dd := dogstatsd.New("wattpad.", logger)
	report := time.NewTicker(time.Second)
	defer report.Stop()
	go dd.SendLoop(report.C, "udp", ddHost)
	return dd
}

// initializeSQSConsumer returns a new initialized SQS Consumer
func initializeSQSConsumer(logger kitlog.Logger, queueName, sqsEndpoint, region string) (*sqsconsumer.SQSService, error) {
	s, err := sqsconsumer.SQSServiceForQueue(queueName,
		func(c *aws.Config) {
			e := sqsEndpoint
			fmt.Printf("Using region: %s Endpoint: %s\n", region, e)
			c.Region = &region
			c.Endpoint = &e
			c.MaxRetries = aws.Int(0)
		})
	if err != nil {
		logger.Log("msg", "sqs.setuperror", "error", err.Error(), "queueName", queueName)
		return nil, errors.New("SQS setup error")
	}

	return s, nil
}

// datadogTimeTrackerMiddleware is a handler decorator that tracks worker runtime
func datadogTimeTrackerMiddleware(hist metrics.Histogram) middleware.MessageHandlerDecorator {
	if hist == nil {
		hist = discard.NewHistogram()
	}

	return func(fn sqsconsumer.MessageHandlerFunc) sqsconsumer.MessageHandlerFunc {
		return func(ctx context.Context, msg string) error {
			start := time.Now()

			err := fn(ctx, msg)
			status := "success"
			if err != nil {
				status = "failure"
			}

			hist.With("status", status).Observe(float64(time.Since(start) / time.Millisecond))

			return err
		}
	}
}
