package packaging

import (
	"encoding/json"
	"fmt"
	"os"
	"time"

	"services/offline-packager/internal/comments"
	"services/offline-packager/internal/instrumentation"
	"services/offline-packager/internal/media"
	"services/offline-packager/internal/queue"
	"services/offline-packager/internal/storage"

	"github.com/go-kit/kit/log"
	"github.com/pkg/errors"
	"golang.org/x/net/context"
)

var (
	ErrAlreadyProcessed       = errors.New("part already being generated")
	ErrDoNotRedeliver   error = nil
)

type Consumer struct {
	persister storage.Persister
	media     media.Parts
	comment   comments.Parts
	logger    log.Logger
	tracker   instrumentation.Tracker
}

func NewController(l log.Logger, t instrumentation.Tracker, m media.Parts, c comments.Parts, p storage.Persister) *Consumer {
	return &Consumer{
		persister: p,
		media:     m,
		logger:    l,
		tracker:   t,
		comment:   c,
	}
}

func (c Consumer) ProcessMessage(_ context.Context, msg string) error {
	start := time.Now()

	defer func() {
		c.tracker.TrackPackagingTime("all", time.Since(start).Seconds()*1000)
	}()

	m, err := processMessage(msg)
	if err != nil {
		c.tracker.TrackWorkerError()
		c.logger.Log("msg", "packaging.processMessage", "error", err, "partid", m.PartID)
		return ErrDoNotRedeliver
	}

	exists, err := c.persister.PartExists(m.PartID)
	if err != nil {
		c.tracker.TrackWorkerError()
		c.logger.Log("msg", "packaging.generation.partExists", "error", err, "partid", m.PartID)
		return err
	}
	if exists {
		return ErrDoNotRedeliver
	}

	if err := c.handleLock(m.PartID); err != nil {
		if err == ErrAlreadyProcessed {
			return ErrDoNotRedeliver
		}
		c.tracker.TrackWorkerError()
		return err
	}

	filename, err := c.generatePackage(m.StoryID, m.PartID)
	if err != nil {
		c.tracker.TrackWorkerError()
		return err
	}

	if err := c.persister.Put(m.PartID, filename); err != nil {
		c.tracker.TrackWorkerError()
		c.logger.Log("msg", "packaging.generation.put", "error", err, "partid", m.PartID)
		return err
	}

	if err := c.persister.Unlock(m.PartID); err != nil {
		c.tracker.TrackWorkerError()
		c.logger.Log("msg", "packaging.generation.deleteLock", "error", err, "partid", m.PartID)
	}

	if err := os.Remove(filename); err != nil {
		c.tracker.TrackWorkerError()
		c.logger.Log("msg", "packaging.generation.deleteZip", "error", err, "partid", m.PartID)
	}

	return nil
}

func (c Consumer) handleLock(partID string) error {
	locked, err := c.persister.IsLocked(partID)
	if err != nil {
		c.logger.Log("msg", "packaging.generation.islocked", "error", err, "partid", partID)
		return err
	}
	if locked {
		return ErrAlreadyProcessed
	}

	if err := c.persister.Lock(partID); err != nil {
		c.logger.Log("msg", "packaging.generation.setLock", "error", err, "partid", partID)
		return err
	}

	return nil
}

func (c Consumer) generatePackage(storyID, partID string) (string, error) {
	path := fmt.Sprintf("/tmp/offline-packager/%s_%s/", storyID, partID)
	defer os.RemoveAll(path)

	start := time.Now()

	if err := c.media.Fetch(storyID, partID, path); err != nil {
		c.logger.Log("msg", "packaging.generation.media", "error", err, "storyid", storyID, "partid", partID)
		return "", err
	}

	c.tracker.TrackPackagingTime("fetchMedia", time.Since(start).Seconds()*1000)
	start = time.Now()

	if err := c.comment.Fetch(partID, path); err != nil {
		c.logger.Log("msg", "packaging.generation.comments", "error", err, "storyid", storyID, "partid", partID)
		return "", err
	}

	c.tracker.TrackPackagingTime("fetchComments", time.Since(start).Seconds()*1000)

	// TODO: Zipping will happen here. Because I plan to put the code directly here using github.com/pierrre/archivefile
	// since it makes zipping entire directories and subdirectories easy, I don't want to put it in and add hundreds
	// of new line just yet.
	filename := fmt.Sprintf("/tmp/offline-packager/%s.zip", partID)

	return filename, nil
}

func processMessage(msg string) (queue.Message, error) {
	var m queue.Message
	err := json.Unmarshal([]byte(msg), &m)

	return m, err
}
