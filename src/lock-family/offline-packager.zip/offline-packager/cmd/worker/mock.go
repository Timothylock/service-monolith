package main

// These are used to mock out the internal packages so that we can develop them later
type mockMediaFetcher struct {
}

func (m mockMediaFetcher) Fetch(storyID, partID, path string) error {
	return nil
}

type mockCommentFetcher struct {
}

func (m mockCommentFetcher) Fetch(partID, path string) error {
	return nil
}
