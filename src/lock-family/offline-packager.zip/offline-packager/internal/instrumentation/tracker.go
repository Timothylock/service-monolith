package instrumentation

import (
	"time"

	"github.com/go-kit/kit/metrics"
	"github.com/go-kit/kit/metrics/dogstatsd"
)

const sampleRate = 1

type Tracker struct {
	responseTime   metrics.Histogram
	serverErrors   metrics.Counter
	workerErrors   metrics.Counter
	validationTime metrics.Histogram
	packagingTime  metrics.Histogram
}

func New(address string, flushInterval time.Duration, statsd dogstatsd.Dogstatsd) *Tracker {
	// connect with UDP since we don't need guaranteed delivery
	go statsd.SendLoop(time.Tick(flushInterval), "udp", address)

	return &Tracker{
		responseTime:   statsd.NewTiming("offlinepackager.server.request.time", sampleRate),
		serverErrors:   statsd.NewCounter("offlinepackager.server.error", sampleRate),
		workerErrors:   statsd.NewCounter("offlinepackager.worker.error", sampleRate),
		validationTime: statsd.NewTiming("offlinepackager.server.validation.time", sampleRate),
		packagingTime:  statsd.NewTiming("offlinepackager.worker.packaging.time", sampleRate),
	}
}

func (m *Tracker) TrackResponseTime(roundTripTime float64) {
	m.responseTime.Observe(roundTripTime)
}

func (m *Tracker) TrackServerError() {
	m.serverErrors.Add(1)
}

func (m *Tracker) TrackWorkerError() {
	m.workerErrors.Add(1)
}

func (m *Tracker) TrackValidationTime(roundTripTime float64) {
	m.validationTime.Observe(roundTripTime)
}

func (m *Tracker) TrackPackagingTime(op string, roundTripTime float64) {
	m.packagingTime.With("op", op).Observe(roundTripTime)
}
