package storage

import (
	"encoding/json"
	"fmt"
	"hash/fnv"
	"time"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/pkg/errors"
)

type parts struct {
	storage *s3.S3
	bucket  string
}

func New(st *s3.S3, b string) parts {
	return parts{
		storage: st,
		bucket:  b,
	}
}

func (s parts) Get(partID string) (string, error) {
	hash := fnv.New64a()
	hash.Write([]byte(partID))
	keyName := fmt.Sprintf("%s-%s.zip", hash.Sum64(), partID)

	params := &s3.HeadObjectInput{
		Bucket: aws.String(s.bucket),
		Key:    aws.String(keyName),
	}

	getInput := &s3.GetObjectInput{
		Bucket: aws.String(s.bucket),
		Key:    aws.String(keyName),
	}

	// Make sure that the file exists
	_, err := s.storage.HeadObject(params)
	if aerr, ok := err.(awserr.Error); ok {
		switch aerr.Code() {
		case "NotFound":
			return "", ErrNotFound
		default:
			return "", aerr
		}
	} else if err != nil {
		return "", err
	}

	// Get the URL for the object and send the signed one back
	req, _ := s.storage.GetObjectRequest(getInput)
	url, err := req.Presign(30 * time.Minute)
	if err != nil {
		pb, err := json.Marshal(params)
		if err != nil {
			return "", err
		}
		return "", errors.Wrap(err, string(pb))
	}

	return url, nil
}

// PartExists returns whether the part file already exists in the datastore
func (s parts) PartExists(partID string) (bool, error) {
	return false, nil // Not Implemented
}

// Put stores a file to the persistent storage
func (s parts) Put(partID, filePath string) error {
	return nil // Not Implemented
}

// IsLocked returns a boolean depending on whether a lock file has been found for a specific part or not
func (s parts) IsLocked(partID string) (bool, error) {
	return false, nil // Not Implemented
}

// Lock sets a lock in for a partID
func (s parts) Lock(partID string) error {
	return nil // Not Implemented
}

// Unlock removes a lock file for a partID
func (s parts) Unlock(partID string) error {
	return nil // Not Implemented
}
