package storage

import "github.com/pkg/errors"

var (
	ErrNotFound = errors.New("part not found in storage")
)

// Persister is the interface that wraps the operations that can be performed on an a story bundle file
type Persister interface {
	// Get fetches the signed URL to the file being requested
	Get(partID string) (string, error)

	// PartExists returns whether the part file already exists in the datastore
	PartExists(partID string) (bool, error)

	// Put stores a file to the persistent storage
	Put(partID, filePath string) error

	// IsLocked returns a boolean depending on whether a lock file has been found for a specific part or not
	IsLocked(partID string) (bool, error)

	// Lock sets a lock in for a partID
	Lock(partID string) error

	// Unlock removes a lock file for a partID
	Unlock(partID string) error
}
