package storage

import (
	"fmt"
	fakeS3 "libraries/awsstub/s3"
	"testing"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/stretchr/testify/assert"
)

const bucket = "wattpad.offline-packager"

func TestGet(t *testing.T) {
	mockS3 := fakeS3.New()
	defer mockS3.Close()
	mockS3.AddObject(bucket, "123456.zip", fakeS3.Object{Type: "text/plain", Body: []byte("Who lives in a pineapple under the sea?")})

	for i, tc := range []struct {
		key         string
		expectFound bool
		expectErr   bool
	}{
		{key: "doesnotexist", expectFound: false, expectErr: true},
		{key: "123456", expectFound: true, expectErr: false},
	} {
		t.Run(fmt.Sprintf("testcase %d", i), func(t *testing.T) {
			mockURL := mockS3.URL

			cfg := aws.NewConfig().WithEndpoint(mockURL).WithRegion("us-east-1").WithS3ForcePathStyle(true).WithCredentials(credentials.NewStaticCredentials("id", "secret", ""))
			sss := s3.New(session.Must(session.NewSession(cfg)))

			store := New(sss, bucket)

			u, err := store.Get(tc.key)

			assert.Equal(t, tc.expectFound, u != "")
			assert.Equal(t, tc.expectErr, err == ErrNotFound)
		})
	}
}

func TestS3Down(t *testing.T) {
	cfg := aws.NewConfig().WithEndpoint("bikiniBottom").WithRegion("us-east-1").WithS3ForcePathStyle(true).WithCredentials(credentials.NewStaticCredentials("id", "secret", ""))
	sss := s3.New(session.Must(session.NewSession(cfg)))

	store := New(sss, bucket)

	_, err := store.Get("123456")
	assert.NotNil(t, err)
}
