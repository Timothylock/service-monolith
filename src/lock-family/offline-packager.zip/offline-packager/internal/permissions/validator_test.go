package permissions

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestValidate(t *testing.T) {
	for i, tc := range []struct {
		serverStatusCode int
	}{
		{serverStatusCode: 200},
		{serverStatusCode: 400},
		{serverStatusCode: 500},
	} {
		t.Run(fmt.Sprintf("testcase %d", i), func(t *testing.T) {
			ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(tc.serverStatusCode)
			}))
			defer ts.Close()

			v := New(ts.URL + "/v4/parts/%s?wp_token=%s")
			result, err := v.Validate("1234", "1234")

			if tc.serverStatusCode == 500 {
				assert.NotNil(t, err)
			} else {
				assert.Nil(t, err)
			}

			assert.Equal(t, tc.serverStatusCode == 200, result)
		})
	}
}
