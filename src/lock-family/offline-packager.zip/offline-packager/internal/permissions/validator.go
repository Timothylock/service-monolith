package permissions

import (
	"fmt"
	"net/http"
	"time"

	"github.com/pkg/errors"
	"github.com/streadway/handy/breaker"
)

const durationUnused = 0

type validator struct {
	url     string
	breaker breaker.Breaker
	client  *http.Client
}

func New(url string) validator {
	return validator{
		url:     url,
		breaker: breaker.NewBreaker(0.1),
		client:  &http.Client{Timeout: time.Second * 10},
	}
}

func (v validator) Validate(partID, token string) (bool, error) {
	if !v.breaker.Allow() {
		return false, breaker.ErrCircuitOpen
	}

	res, err := v.client.Get(fmt.Sprintf(v.url, partID, token))
	if err != nil {
		v.breaker.Failure(durationUnused)
		return false, err
	}

	res.Body.Close()

	if res.StatusCode == 500 {
		v.breaker.Failure(durationUnused)
		return false, errors.New("external error during validation")
	}

	v.breaker.Success(durationUnused)
	return res.StatusCode == 200, nil
}
