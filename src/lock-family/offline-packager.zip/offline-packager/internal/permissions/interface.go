package permissions

type Validator interface {
	// Validate checks to see if the current user is allowed to view the part
	Validate(partID, token string) (bool, error)
}
