package media

// Parts is the interface that wraps the operations that can be performed on the media for a part
type Parts interface {
	// Fetch obtains the media for a story and stores it into the specified directory
	Fetch(storyID, partID, path string) error
}
