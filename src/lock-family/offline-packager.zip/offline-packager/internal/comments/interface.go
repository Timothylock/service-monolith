package comments

// Parts is the interface that wraps the operations that can be performed on the comments for a part
type Parts interface {
	// Fetch obtains the comments and stores it into the specified directory
	Fetch(partID, path string) error
}
