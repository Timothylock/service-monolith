package queue

// Message is a struct containing the payload of a message
type Message struct {
	PartID  string `json:"PartID"`
	StoryID string `json:"StoryID"`
}

// Messaging is the interface that wraps the operations that can be performed on the messaging queue
type Messaging interface {
	// Post puts a new Message with the storyID and partID into the queue
	Post(msg Message) error
}
