package queue

import (
	"encoding/json"
	sqsStub "libraries/awsstub/sqs"
	"reflect"
	"testing"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/sqs"
)

func TestSQS(t *testing.T) {
	ssqs := sqsStub.New()
	defer ssqs.Close()

	config := &aws.Config{
		Endpoint:    aws.String(ssqs.URL),
		Region:      aws.String("us-east-1"),
		Credentials: credentials.AnonymousCredentials,
	}

	s := sqs.New(session.Must(session.NewSession(config)))
	r := New(s, ssqs.URL)

	numMessageBefore := len(ssqs.Messages())

	err := r.Post(Message{PartID: "123456", StoryID: "1234"})
	if err != nil {
		t.Fatalf("expected an InvalidAction but got %s", err.Error())
	}

	messages := ssqs.Messages()
	if len(messages) != numMessageBefore+1 {
		t.Fatalf("expected %d messages on queue but got %d", numMessageBefore+1, len(ssqs.Messages()))
	}

	expected := Message{
		PartID:  "123456",
		StoryID: "1234",
	}
	var actual Message

	err = json.Unmarshal([]byte(messages[0].Body), &actual)
	if err != nil {
		t.Fatal(err)
	}

	if !reflect.DeepEqual(expected, actual) {
		t.Fatalf("Expected %s, got %s", expected, actual)
	}

}
