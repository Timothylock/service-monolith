package queue

import "github.com/aws/aws-sdk-go/service/sqs"

type messaging struct {
	sqs      *sqs.SQS
	endpoint string
}

func New(s *sqs.SQS, e string) messaging {
	return messaging{
		sqs:      s,
		endpoint: e,
	}
}

func (m messaging) Post(ms Message) error {
	return nil
}
