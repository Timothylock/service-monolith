package config

import (
	"fmt"
	"time"

	"github.com/kelseyhightower/envconfig"
)

type Config struct {
	DatadogFlushInterval time.Duration `split_words:"true" default:"1s"`
	DatadogAddress       string        `ignored:"true"`
	DogstatsdHost        string        `split_words:"true" required:"true"`
	DogstatsdPort        int           `split_words:"true" default:"8125"`
	AWSRegion            string        `envconfig:"AWS_REGION" required:"true"`
	S3Bucket             string        `envconfig:"S3_BUCKET" required:"true"`
	SQSURL               string        `envconfig:"SQS_URL" required:"true"`
	ValidatorURL         string        `envconfig:"VALIDATOR_URL" required:"true"`
}

func FromEnvironment() (*Config, error) {
	var cfg Config
	if err := envconfig.Process("", &cfg); err != nil {
		return nil, err
	}

	cfg.DatadogAddress = fmt.Sprintf("%s:%d", cfg.DogstatsdHost, cfg.DogstatsdPort)

	return &cfg, nil
}
